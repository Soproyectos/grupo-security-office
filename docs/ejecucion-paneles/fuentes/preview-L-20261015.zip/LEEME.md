# Fuentes del preview L — integrar, no reemplazar

Snapshot del worktree local L, 15 de octubre de 2026. Contiene código fuente y pruebas, no credenciales, bases de datos ni node_modules. Los archivos bajo source/ son referencias para integrar en la copia aislada gs-tanda-01. No extraer sobre S3 ni copiar indiscriminadamente sobre archivos ya modificados por la tanda.

1. Verificar MANIFEST.json y extraer a una carpeta de referencias separada.
2. Integrar modules/prices/import y features/price-import, manteniendo controles del contenedor/XML y las pruebas.
3. Integrar el montaje en PricesModule y pestaña/servicio frontend mediante merge: ListaDetailPage ya tiene cambios CAT-01 que se conservan.
4. access-catalog, guards, identidad, sesiones y ACL son referencias de L, no reemplazos del nuevo modelo de concesiones. Adaptar prices:preview + prices:read + listas:read y alcance view_prices, incluida restricción PRODUCT. No activar AdminAccessGuard de L en S3 sin inventariar las rutas.
5. package.json/lock son referencias. Añadir sax 1.6.1 a las dependencias de la copia preservando las demás; no sustituir su lock completo.
6. Revalidar permisos actuales por solicitud. No crear excepciones globales para hacer pasar el preview.
7. Ejecutar pruebas focales y PostgreSQL desechable de IMP-01; actualizar evidencias del bloqueo una vez integrado. El paquete no demuestra compatibilidad con la base de la tanda.

El preview compara sin aplicar ni persistir revisiones. No reconstruirlo desde cero. ORO_IVA es exacto, no alias de DPP_ORO_IVA. Continúan pendientes guardar/aplicar, historial y su auditoría final.
