import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuditService } from '../../modules/audit/audit.service';
import { ACCESS_ACTIONS, ACCESS_ROUTES } from '../security/access-catalog';
import { AdminAccessGuard } from './admin-access.guard';

const context = (controller: string, handler: string, user?: object): ExecutionContext => ({
  getClass: () => ({ name: controller }), getHandler: () => ({ name: handler }),
  switchToHttp: () => ({ getRequest: () => ({ user }) }),
} as unknown as ExecutionContext);

describe('Administrative access guard', () => {
  const reflector = { getAllAndOverride: jest.fn().mockReturnValue(false) };
  const audit = { log: jest.fn().mockResolvedValue({}) };
  const guard = new AdminAccessGuard(reflector as unknown as Reflector, audit as unknown as AuditService);
  beforeEach(() => { jest.clearAllMocks(); reflector.getAllAndOverride.mockReturnValue(false); });

  for (const [controller, routes] of Object.entries(ACCESS_ROUTES)) {
    for (const [handler, rule] of Object.entries(routes)) {
      if (!Array.isArray(rule)) continue;
      it(`${controller}.${handler}: denies unassigned role, permits exact action and dependencies`, async () => {
        const ctx = (permissions: string[]) => context(controller, handler, { sub: 'user-test', roles: ['Consulta'], permissions });
        await expect(guard.canActivate(ctx([]))).rejects.toThrow(ForbiddenException);
        const permissions = [...new Set(rule.flatMap((p) => [p, ...(ACCESS_ACTIONS.get(p)?.requires ?? [])]))];
        await expect(guard.canActivate(ctx(permissions))).resolves.toBe(true);
        for (const required of rule) await expect(guard.canActivate(ctx(permissions.filter((p) => p !== required)))).rejects.toThrow(ForbiddenException);
      });
    }
  }

  it('does not allow inventing a route, even for Super Admin', async () => {
    await expect(guard.canActivate(context('UsersController', 'newSecretRoute', { roles: ['Super Admin'] }))).rejects.toThrow(ForbiddenException);
  });
  it('allows a store section independently of the other sections', async () => {
    for (const permission of ['storefront:read', 'customerAccounts:read', 'inquiries:read']) {
      await expect(guard.canActivate(context('StorefrontAdminController', 'overview', { roles: ['Consulta'], permissions: [permission] }))).resolves.toBe(true);
    }
    await expect(guard.canActivate(context('StorefrontAdminController', 'overview', { roles: ['Admin Comercial'], permissions: [] }))).rejects.toThrow(ForbiddenException);
  });
  it('keeps assignment and identity administration reserved to Super Admin', async () => {
    await expect(guard.canActivate(context('UsersController', 'setAccess', { roles: ['Admin Comercial'], permissions: ['users:manage'] }))).rejects.toThrow(ForbiddenException);
    await expect(guard.canActivate(context('UsersController', 'setAccess', { roles: ['Super Admin'] }))).resolves.toBe(true);
  });
  it('allows personal account actions without assigned panels', async () => {
    await expect(guard.canActivate(context('AuthController', 'getProfile', { roles: [], permissions: [] }))).resolves.toBe(true);
  });
  it('does not interfere with public catalog or customer sessions', async () => {
    reflector.getAllAndOverride.mockReturnValue(true);
    await expect(guard.canActivate(context('StorefrontController', 'products'))).resolves.toBe(true);
    expect(audit.log).not.toHaveBeenCalled();
  });
});
