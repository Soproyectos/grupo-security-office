import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { ACCESS_ACTIONS, accessRule, hasAction } from '../security/access-catalog';
import { AuditService } from '../../modules/audit/audit.service';

/** Administrative actions are assigned individually; unclassified routes fail closed. */
@Injectable()
export class AdminAccessGuard implements CanActivate {
  constructor(private reflector: Reflector, private audit: AuditService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [context.getHandler(), context.getClass()])) return true;
    const request = context.switchToHttp().getRequest();
    const rule = accessRule(context.getClass().name, context.getHandler().name);
    const user = request.user;
    const allowed = !!user && rule !== undefined && (
      rule === 'account' || user.roles?.includes('Super Admin') ||
      (Array.isArray(rule) && rule.every((p) =>
        hasAction(user, p) && (ACCESS_ACTIONS.get(p)?.requires ?? []).every((r) => hasAction(user, r)),
      )) || (typeof rule === 'object' && !Array.isArray(rule) && rule.anyOf.some((p) => hasAction(user, p) && (ACCESS_ACTIONS.get(p)?.requires ?? []).every((r) => hasAction(user, r))))
    );
    if (allowed) return true;
    if (user?.sub) await this.audit.log({
      userId: user.sub, action: 'access-denied', entity: 'AdminAccess',
      entityId: `${context.getClass().name}.${context.getHandler().name}`,
      newValues: { required: rule ?? 'unclassified' }, result: 'WARNING',
    });
    throw new ForbiddenException('No tienes asignada esta acción. Solicita acceso al Super Admin.');
  }
}
