/** The API owns the list of assignable actions. New routes fail closed. */
export interface AccessPanel {
  id: string;
  area: string;
  title: string;
  description: string;
  actions: { permission: string; label: string; requires: string[] }[];
}

const labels: Record<string, string> = {
  read: 'Ver', create: 'Crear', edit: 'Editar', delete: 'Eliminar',
  publish: 'Publicar y retirar publicación', archive: 'Archivar y restaurar',
  duplicate: 'Duplicar', import: 'Importar', approve: 'Aprobar cuentas',
  resolve: 'Atender consultas', invoice: 'Registrar factura',
  convert: 'Convertir prospecto', status: 'Cambiar estado', manage: 'Gestionar accesos',
  preview: 'Revisar archivo de precios',
};

function panel(id: string, area: string, title: string, actions: string[], description: string): AccessPanel {
  return { id, area, title, description, actions: actions.map((action) => ({
    permission: `${id}:${action}`, label: labels[action] ?? action,
    requires: action === 'read' ? [] : [`${id}:read`],
  })) };
}

export const ACCESS_PANELS: AccessPanel[] = [
  panel('products', 'Catálogo', 'Productos', ['read', 'create', 'edit', 'publish', 'archive', 'delete', 'import'], 'Requiere también acceso a la Lista del producto. Publicar no permite editar.'),
  panel('categories', 'Catálogo', 'Categorías', ['read', 'create', 'edit', 'delete'], 'Catálogo compartido de categorías.'),
  panel('brands', 'Catálogo', 'Marcas', ['read', 'create', 'edit', 'delete'], 'Marcas y sus logos.'),
  panel('prices', 'Catálogo', 'Tarifas', ['read', 'create', 'edit', 'delete', 'preview'], 'Tarifas y precios; se conserva el alcance de datos de las Listas. Revisar un archivo no aplica sus precios ni concede acceso a Biblioteca.'),
  panel('listas', 'Catálogo', 'Listas', ['read', 'create', 'edit', 'duplicate', 'publish', 'archive', 'delete'], 'La asignación de una acción no reemplaza el acceso a cada Lista.'),
  panel('assignments', 'Catálogo', 'Acceso a Listas', ['read', 'manage'], 'Gestiona los niveles de acceso a recursos; no concede paneles administrativos.'),
  panel('customers', 'Trabajo comercial', 'Clientes y prospectos', ['read', 'create', 'edit', 'convert', 'delete'], 'Se conserva el alcance de cartera propia y equipo.'),
  panel('quotes', 'Trabajo comercial', 'Cotizaciones', ['read', 'create', 'edit', 'status'], 'Cotizaciones dentro de la cartera y Listas autorizadas.'),
  panel('orders', 'Trabajo comercial', 'Pedidos', ['read', 'invoice'], 'Pedidos autorizados y registro de facturación externa.'),
  panel('targets', 'Trabajo comercial', 'Metas', ['read', 'edit'], 'La jerarquía limita sobre qué integrantes se fijan metas.'),
  panel('storefront', 'Configuración de la página', 'Información comercial', ['read', 'edit'], 'Información de contacto, documentos oficiales y tarifas públicas.'),
  panel('banners', 'Configuración de la página', 'Banners', ['read', 'create', 'edit', 'publish', 'delete'], 'Prepara imágenes para móvil y escritorio. Editar guarda un borrador; publicar cambia lo que ve el visitante.'),
  panel('customerAccounts', 'Gestión de tienda', 'Cuentas de clientes', ['read', 'approve'], 'Solicitudes de acceso profesional y aprobación de cuentas.'),
  panel('inquiries', 'Gestión de tienda', 'Consultas de visitantes', ['read', 'resolve'], 'Consultas recibidas por el catálogo público.'),
  panel('dashboard', 'Informes', 'Resumen de trabajo', ['read'], 'Resumen completo dentro del alcance actual de Listas, cartera y equipo; incluye indicadores y actividad.'),
  panel('catalogInsights', 'Informes', 'Indicadores de catálogo', ['read'], 'Agregados globales de catálogo; no permite editar productos.'),
  panel('commercialInsights', 'Informes', 'Indicadores comerciales', ['read'], 'Ventas y clientes dentro del alcance comercial actual.'),
  panel('teamInsights', 'Informes', 'Resumen de integrantes', ['read'], 'Solo personas autorizadas por la jerarquía.'),
  panel('users', 'Administración', 'Usuarios', ['read'], 'Consulta de integrantes. Crear, modificar, eliminar usuarios y repartir paneles se reserva a Super Admin.'),
  panel('audit', 'Administración', 'Auditoría', ['read'], 'Consulta del historial con los límites de entidad y jerarquía actuales. No permite borrar registros.'),
  {
    id: 'scope', area: 'Alcance de datos', title: 'Datos autorizados',
    description: 'Las acciones y el alcance son independientes. Sin estas casillas se usan tus asignaciones y cartera. Ampliar el alcance no habilita ninguna acción.',
    actions: [
      { permission: 'scope:catalog:all', label: 'Todas las Listas del catálogo', requires: [] },
      { permission: 'scope:commercial:team', label: 'Cartera del equipo en tu jerarquía', requires: [] },
      { permission: 'scope:commercial:all', label: 'Cartera comercial de toda la empresa', requires: [] },
    ],
  },
];

export const ACCESS_ACTIONS = new Map(ACCESS_PANELS.flatMap((p) => p.actions.map((a) => [a.permission, a] as const)));

// Picker dependencies are explicit, shown in Users → Panels and validated when saving.
for (const permission of ['products:create', 'products:edit']) {
  ACCESS_ACTIONS.get(permission)!.requires.push('categories:read', 'brands:read', 'listas:read');
}
ACCESS_ACTIONS.get('quotes:create')!.requires.push('customers:read', 'listas:read');
ACCESS_ACTIONS.get('quotes:edit')!.requires.push('products:read', 'prices:read', 'listas:read');
ACCESS_ACTIONS.get('assignments:manage')!.requires.push('users:read', 'listas:read');
ACCESS_ACTIONS.get('listas:publish')!.requires.push('products:read', 'products:publish');
ACCESS_ACTIONS.get('products:import')!.requires.push('scope:catalog:all', 'categories:create', 'categories:read', 'brands:create', 'brands:read', 'prices:create', 'prices:edit', 'prices:read');
ACCESS_ACTIONS.get('prices:preview')!.requires.push('listas:read');
export type AccessRule = string[] | 'account' | 'superadmin' | { anyOf: string[] };

/** Explicit handler inventory; no URL guessing, action-name inference or role inheritance. */
export const ACCESS_ROUTES: Record<string, Record<string, AccessRule>> = {
  AuthController: Object.fromEntries(['getProfile', 'listSessions', 'revokeOtherSessions', 'disableMfa', 'logout'].map((name) => [name, 'account'])),
  UsersController: {
    findAll: ['users:read'], findOne: ['users:read'], getMyTeam: ['teamInsights:read'],
    create: 'superadmin', update: 'superadmin', remove: 'superadmin', setSupervisor: 'superadmin',
    getDashboardPermissions: 'superadmin', setDashboardPermissions: 'superadmin',
    getAccess: 'superadmin', setAccess: 'superadmin', unlockAccount: 'superadmin',
  },
  RolesController: { findAll: 'superadmin', findOne: 'superadmin', create: 'superadmin', update: 'superadmin', remove: 'superadmin' },
  ProductsController: {
    findTrending: ['products:read', 'prices:read', 'scope:catalog:all'], findPublishScheduled: ['products:read', 'scope:catalog:all'], findAll: ['products:read'], findOne: ['products:read'],
    create: ['products:create'], update: ['products:edit'], toggleVisibility: ['products:publish'], toggleActive: ['products:archive'],
    publish: ['products:publish'], unpublish: ['products:publish'], transition: ['products:read'], bulkTransition: ['products:read'],
    remove: ['products:delete'], importExcel: ['products:import'], uploadImage: ['products:edit'], removeImage: ['products:edit'], updateImage: ['products:edit'],
    schedulePublication: ['products:publish'], cancelScheduledPublication: ['products:publish'], schedulePublicationBulk: ['products:publish'], cancelPublicationBulk: ['products:publish'],
  },
  ListasPublicationController: { publishLista: ['listas:publish', 'products:publish'], scheduleLista: ['listas:publish', 'products:publish'], cancelLista: ['listas:publish', 'products:publish'] },
  CategoriesController: { findAll: ['categories:read'], findTree: ['categories:read'], findOne: ['categories:read'], create: ['categories:create'], update: ['categories:edit'], remove: ['categories:delete'] },
  BrandsController: { findAll: ['brands:read'], findOne: ['brands:read'], create: ['brands:create'], update: ['brands:edit'], toggleActive: ['brands:edit'], uploadLogo: ['brands:edit'], remove: ['brands:delete'] },
  PricesController: { findAllPriceLists: ['prices:read'], findOnePriceList: ['prices:read'], findPricesByProduct: ['prices:read'], findPricesByPriceList: ['prices:read'], createPriceList: ['prices:create'], createPrice: ['prices:create'], updatePriceList: ['prices:edit'], togglePriceListActive: ['prices:edit'], updatePrice: ['prices:edit'], removePriceList: ['prices:delete'], removePrice: ['prices:delete'] },
  ListasController: { findAll: ['listas:read'], findOne: ['listas:read'], findProducts: ['listas:read', 'products:read'], findPrices: ['listas:read', 'prices:read'], findExpiringPrices: ['listas:read', 'prices:read'], findAssignments: ['assignments:read'], findAudit: ['audit:read'], create: ['listas:create'], duplicate: ['listas:duplicate'], update: ['listas:edit'], toggleActive: ['listas:edit'], archive: ['listas:archive'], restore: ['listas:archive'], deletionRequest: ['listas:delete'], remove: ['listas:delete'] },
  AssignmentsController: { findAll: ['assignments:read'], matrix: ['assignments:read'], preview: ['assignments:read'], create: ['assignments:manage'], update: ['assignments:manage'], remove: ['assignments:manage'] },
  ImportController: { preview: ['products:import'], execute: ['products:import'], getProgress: ['products:import'], getCurrentPrice: ['prices:read', 'scope:catalog:all'], getCurrentPrices: ['prices:read', 'scope:catalog:all'], listPresets: ['products:import'], savePreset: ['products:import'], deletePreset: ['products:import'] },
  PriceImportController: { preview: ['prices:preview'] },
  CustomersController: { findAll: ['customers:read'], findOne: ['customers:read'], create: ['customers:create'], update: ['customers:edit'], convert: ['customers:convert'], remove: ['customers:delete'] },
  QuotesController: { findAll: ['quotes:read'], findOne: ['quotes:read'], create: ['quotes:create'], addItem: ['quotes:edit'], updateItem: ['quotes:edit'], removeItem: ['quotes:edit'], updateStatus: ['quotes:status'] },
  SalesOrdersController: { findAll: ['orders:read'], findOne: ['orders:read'], updateInvoice: ['orders:invoice'] },
  SalesTargetsController: { findAll: ['targets:read'], upsert: ['targets:edit'] },
  StorefrontAdminController: { overview: { anyOf: ['storefront:read', 'customerAccounts:read', 'inquiries:read'] }, settings: ['storefront:edit'], review: ['customerAccounts:approve'], resolve: ['inquiries:resolve'] },
  BannersAdminController: { list: ['banners:read'], create: ['banners:create'], edit: ['banners:edit'], publish: ['banners:publish'], remove: ['banners:delete'], upload: { anyOf: ['banners:create', 'banners:edit'] } },
  DashboardController: { getMyWorkspace: ['dashboard:read'], getCatalogInsights: ['catalogInsights:read'], getUsersInsights: ['users:read'], getTopCustomers: ['commercialInsights:read'], getSalesByCategory: ['commercialInsights:read'], getTeamMember: ['teamInsights:read'] },
  AuditController: { findAll: ['audit:read'], findByEntity: ['audit:read'] },
};

export function accessRule(controller: string, handler: string): AccessRule | undefined {
  return ACCESS_ROUTES[controller]?.[handler];
}

export function hasAction(user: { roles?: string[]; permissions?: string[] } | undefined, permission: string): boolean {
  return !!user && (user.roles?.includes('Super Admin') === true || user.permissions?.includes(permission) === true);
}
