jest.mock('../../prisma/prisma.service', () => ({ PrismaService: class {} }));
import { Controller, Get, INestApplication, UseGuards } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { APP_GUARD } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { JwtStrategy } from '../../modules/auth/jwt.strategy';
import { RolesGuard } from '../guards/roles.guard';
import { PermissionsGuard } from '../guards/permissions.guard';
import { Roles } from '../decorators/roles.decorator';
import request = require('supertest');
import { AdminAccessGuard } from '../guards/admin-access.guard';
import { LiveAdminIdentityService } from './live-admin-identity.service';
import { PrismaService } from '../../prisma/prisma.service';
import { SessionService } from './session.service';
import { AuditService } from '../../modules/audit/audit.service';
import { JwtAuthGuard } from '../../modules/auth/jwt-auth.guard';
import { Public } from '../decorators/public.decorator';

@Controller('products')
@UseGuards(RolesGuard, PermissionsGuard)
class ProductsController {
  @Roles('Super Admin', 'Admin Comercial') @Get() findAll() { return { fixture: 'authorized internal product' }; }
}
@Controller('auth')
class AuthController {
  @Get('profile') getProfile() { return { fixture: 'own account' }; }
}
@Controller('public')
class PublicController {
  @Public() @Get() catalog() { return { fixture: 'public catalog' }; }
}

describe('Assigned actions through HTTP and signed sessions', () => {
  let app: INestApplication;
  let permissions: { permission: string; effect: string }[];
  let active: boolean;
  let sessionActive: boolean;
  let roles: string[];
  const jwt = new JwtService({ secret: 'test-only-integrated-access-secret' });
  const token = jwt.sign({ sub: 'fixture-person', jti: 'fixture-session', roles: ['Super Admin'], permissions: ['products:read'] });
  const audit = { log: jest.fn().mockResolvedValue({}) };
  beforeAll(async () => {
    const prisma = { user: { findUnique: jest.fn(async () => ({ id: 'fixture-person', name: 'Fixture', email: 'fixture@example.test', isActive: active, roles: roles.map((name) => ({ role: { name } })), extraPermissions: permissions })) } };
    const sessions = { isActive: jest.fn(async () => sessionActive) };
    const identity = new LiveAdminIdentityService(prisma as unknown as PrismaService, sessions as unknown as SessionService);
    const module = await Test.createTestingModule({
      controllers: [ProductsController, AuthController, PublicController],
      providers: [JwtStrategy, RolesGuard, PermissionsGuard,
        { provide: ConfigService, useValue: { get: () => 'test-only-integrated-access-secret' } },
        { provide: LiveAdminIdentityService, useValue: identity }, { provide: AuditService, useValue: audit },
        { provide: APP_GUARD, useClass: JwtAuthGuard }, { provide: APP_GUARD, useClass: AdminAccessGuard }],
    }).compile();
    app = module.createNestApplication();
    await app.init();
  });
  beforeEach(() => { permissions = []; active = true; sessionActive = true; roles = ['Consulta']; audit.log.mockClear(); });
  afterAll(async () => { await app.close(); });

  it('allows a public catalog without internal credentials', async () => { await request(app.getHttpServer()).get('/public').expect(200); });
  it('requires an authenticated session for internal data', async () => { await request(app.getHttpServer()).get('/products').expect(401); });
  it('ignores stale role and permission claims in a signed token', async () => {
    await request(app.getHttpServer()).get('/products').auth(token, { type: 'bearer' }).expect(403);
    expect(audit.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'access-denied', userId: 'fixture-person' }));
  });
  it('applies grants and revocation on the next request using the same token', async () => {
    permissions = [{ permission: 'products:read', effect: 'GRANT' }];
    await request(app.getHttpServer()).get('/products').auth(token, { type: 'bearer' }).expect(200);
    permissions = [];
    await request(app.getHttpServer()).get('/products').auth(token, { type: 'bearer' }).expect(403);
    permissions = [{ permission: 'products:read', effect: 'REVOKE' }];
    await request(app.getHttpServer()).get('/products').auth(token, { type: 'bearer' }).expect(403);
  });
  it('permits own profile without panels', async () => { await request(app.getHttpServer()).get('/auth/profile').auth(token, { type: 'bearer' }).expect(200); });
  it('rejects deactivated users and revoked sessions', async () => {
    active = false;
    await request(app.getHttpServer()).get('/auth/profile').auth(token, { type: 'bearer' }).expect(401);
    active = true; sessionActive = false;
    await request(app.getHttpServer()).get('/auth/profile').auth(token, { type: 'bearer' }).expect(401);
  });
  it('rejects an MFA challenge as a full session', async () => {
    const challenge = jwt.sign({ sub: 'fixture-person', scope: 'mfa' });
    await request(app.getHttpServer()).get('/auth/profile').auth(challenge, { type: 'bearer' }).expect(401);
  });
});
