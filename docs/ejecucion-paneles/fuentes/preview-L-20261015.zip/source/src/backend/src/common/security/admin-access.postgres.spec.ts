jest.mock('../../prisma/prisma.service', () => ({ PrismaService: class {} }));
import { PrismaClient } from '@prisma/client';
import { Body, Controller, Get, INestApplication, Param, Put, Req, ValidationPipe } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Test } from '@nestjs/testing';
import { randomUUID } from 'crypto';
import request = require('supertest');
import { PrismaService } from '../../prisma/prisma.service';
import { JwtStrategy } from '../../modules/auth/jwt.strategy';
import { JwtAuthGuard } from '../../modules/auth/jwt-auth.guard';
import { AdminAccessGuard } from '../guards/admin-access.guard';
import { AuditService } from '../../modules/audit/audit.service';
import { HierarchyService } from '../hierarchy/hierarchy.service';
import { AccessAssignmentsService } from './access-assignments.service';
import { LiveAdminIdentityService } from './live-admin-identity.service';
import { SessionService } from './session.service';
import { AssignAccessDto } from '../../modules/users/dto/assign-access.dto';

const databaseUrl = process.env.ACCESS_TEST_DATABASE_URL;
if (databaseUrl) {
  const url = new URL(databaseUrl);
  if (!['127.0.0.1', 'localhost'].includes(url.hostname) || !url.pathname.startsWith('/gs_access_test')) {
    throw new Error('ACCESS_TEST_DATABASE_URL must point to a disposable local gs_access_test database');
  }
}
const run = databaseUrl ? describe : describe.skip;

@Controller('users')
class UsersController {
  constructor(private assignments: AccessAssignmentsService) {}
  @Get(':id/access') getAccess(@Param('id') id: string) { return this.assignments.snapshot(id); }
  @Put(':id/access') setAccess(@Param('id') id: string, @Body() dto: AssignAccessDto, @Req() req: any) {
    return this.assignments.replace(id, dto.permissions, dto.revision, req.user.sub, dto.reason);
  }
}
@Controller('products')
class ProductsController { @Get() findAll() { return { authorized: true }; } }
@Controller('auth')
class AuthController { @Get('profile') getProfile(@Req() req: any) { return req.user; } }

run('Administrative access with PostgreSQL, HTTP, Passport and real sessions', () => {
  let db: PrismaClient;
  let app: INestApplication;
  let assignments: AccessAssignmentsService;
  let sessions: SessionService;
  let userToken: string;
  let adminToken: string;
  let sessionId: string;
  const ids = [randomUUID(), randomUUID(), randomUUID()];
  const [adminId, userId, otherId] = ids;
  const secret = 'postgres-test-only-secret';
  const jwt = new JwtService({ secret });
  beforeAll(async () => {
    db = new PrismaClient({ datasourceUrl: databaseUrl });
    await db.$connect();
    const role = await db.role.upsert({ where: { name: 'Super Admin' }, create: { name: 'Super Admin' }, update: {} });
    for (const id of ids) await db.user.create({ data: { id, email: `${id}@example.test`, name: 'Access fixture', password: 'test-only-unusable-password' } });
    await db.userRole.create({ data: { userId: adminId, roleId: role.id } });
    const module = await Test.createTestingModule({
      controllers: [UsersController, ProductsController, AuthController],
      providers: [JwtStrategy, AccessAssignmentsService, LiveAdminIdentityService, SessionService, AuditService, HierarchyService,
        { provide: PrismaService, useValue: db },
        { provide: ConfigService, useValue: { get: () => secret } },
        { provide: APP_GUARD, useClass: JwtAuthGuard }, { provide: APP_GUARD, useClass: AdminAccessGuard }],
    }).compile();
    app = module.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }));
    await app.init();
    assignments = module.get(AccessAssignmentsService);
    sessions = module.get(SessionService);
    const jti = await sessions.create({ userId: adminId, expiresAt: new Date(Date.now() + 60000) });
    adminToken = jwt.sign({ sub: adminId, jti });
  });
  beforeEach(async () => {
    await db.userPermission.deleteMany({ where: { userId } });
    await db.user.update({ where: { id: userId }, data: { isActive: true } });
    sessionId = await sessions.create({ userId, expiresAt: new Date(Date.now() + 60000) });
    // Deliberately stale claims: the real database must decide access.
    userToken = jwt.sign({ sub: userId, jti: sessionId, roles: ['Super Admin'], permissions: ['products:read'] });
  });
  afterAll(async () => {
    await app?.close();
    if (!db) return;
    await db.auditLog.deleteMany({ where: { OR: [{ userId: { in: ids } }, { entityId: { in: ids } }] } });
    await db.userPermission.deleteMany({ where: { userId: { in: ids } } });
    await db.session.deleteMany({ where: { userId: { in: ids } } });
    await db.userRole.deleteMany({ where: { userId: { in: ids } } });
    await db.user.deleteMany({ where: { id: { in: ids } } });
    await db.$disconnect();
  });
  const productRequest = () => request(app.getHttpServer()).get('/products').auth(userToken, { type: 'bearer' });
  it('starts blank, persists a grant and revokes it with the same signed session', async () => {
    await productRequest().expect(403);
    const first = await assignments.snapshot(userId);
    await request(app.getHttpServer()).put(`/users/${userId}/access`).auth(adminToken, { type: 'bearer' })
      .send({ permissions: ['products:read'], revision: first.revision, reason: 'Read catalogue' }).expect(200);
    await productRequest().expect(200);
    const granted = await assignments.snapshot(userId);
    await assignments.replace(userId, [], granted.revision, adminId);
    await productRequest().expect(403);
    expect(await db.auditLog.count({ where: { entityId: userId, action: 'assign-user-access', userId: adminId } })).toBe(2);
  });
  it('rejects assigning to another person and incomplete or invented permissions', async () => {
    const snapshot = await assignments.snapshot(otherId);
    await request(app.getHttpServer()).put(`/users/${otherId}/access`).auth(userToken, { type: 'bearer' })
      .send({ permissions: ['products:read'], revision: snapshot.revision }).expect(403);
    for (const permissions of [['products:edit'], ['users:manage']]) {
      await request(app.getHttpServer()).put(`/users/${otherId}/access`).auth(adminToken, { type: 'bearer' })
        .send({ permissions, revision: snapshot.revision }).expect(400);
    }
    expect((await assignments.snapshot(otherId)).permissions).toEqual([]);
  });
  it('serializes competing administrators and rejects the stale revision', async () => {
    const initial = await assignments.snapshot(userId);
    const results = await Promise.allSettled([
      assignments.replace(userId, ['products:read'], initial.revision, adminId),
      assignments.replace(userId, ['products:read', 'products:publish'], initial.revision, adminId),
    ]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    const failure = results.find((r) => r.status === 'rejected') as PromiseRejectedResult;
    expect(failure.reason.getStatus()).toBe(409);
  });
  it('rolls back the actual database replacement if the audit cannot be written', async () => {
    const initial = await assignments.snapshot(userId);
    await assignments.replace(userId, ['products:read'], initial.revision, adminId);
    const current = await assignments.snapshot(userId);
    const failureService = new AccessAssignmentsService({
      $transaction: (fn: any) => db.$transaction((tx) => fn({ user: tx.user, $queryRaw: tx.$queryRaw.bind(tx), userPermission: tx.userPermission,
        auditLog: { create: () => { throw new Error('Injected audit failure'); } } })),
    } as unknown as PrismaService);
    await expect(failureService.replace(userId, [], current.revision, adminId)).rejects.toThrow('Injected audit failure');
    expect((await assignments.snapshot(userId)).permissions).toEqual(['products:read']);
    await productRequest().expect(200);
  });
  it('allows own profile without panels and blocks inactive users or revoked sessions', async () => {
    const profile = () => request(app.getHttpServer()).get('/auth/profile').auth(userToken, { type: 'bearer' });
    await profile().expect(200);
    await db.user.update({ where: { id: userId }, data: { isActive: false } });
    await profile().expect(401);
    await db.user.update({ where: { id: userId }, data: { isActive: true } });
    await sessions.revoke(sessionId, 'ADMIN_REVOKE');
    await profile().expect(401);
  });
});
