import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SessionService } from './session.service';
import { ACCESS_ACTIONS } from './access-catalog';

@Injectable()
export class LiveAdminIdentityService {
  constructor(private prisma: PrismaService, private sessions: SessionService) {}

  async resolve(payload: { sub: string; scope?: string; jti?: string }) {
    if (payload.scope) throw new UnauthorizedException('Token de verificacion, no de sesion');
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub },
      select: {
        id: true, email: true, name: true, isActive: true,
        roles: { select: { role: { select: { name: true } } } },
        extraPermissions: { select: { permission: true, effect: true } },
      },
    });
    if (!user?.isActive) throw new UnauthorizedException('Usuario no encontrado o inactivo');
    if (!(await this.sessions.isActive(payload.jti))) throw new UnauthorizedException('Sesion finalizada. Inicie sesion de nuevo.');
    return {
      sub: user.id, email: user.email, name: user.name,
      roles: user.roles.map((ur) => ur.role.name),
      permissions: user.extraPermissions.filter((g) => g.effect === 'GRANT' && ACCESS_ACTIONS.has(g.permission)).map((g) => g.permission),
      jti: payload.jti,
    };
  }
}
