import { Body, Controller, Post, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiProperty, ApiTags } from '@nestjs/swagger';
import { IsUUID } from 'class-validator';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { JwtAuthGuard } from '../../auth/jwt-auth.guard';
import { PriceImportService } from './price-import.service';
import { MAX_XLSX_BYTES } from './xlsx-container';

export class PriceImportPreviewDto {
  @ApiProperty({ description: 'Lista existente a la que pertenecen las referencias del archivo.' })
  @IsUUID()
  listaId: string;
}

@ApiTags('Prices - Revisión de plantilla')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('api/prices/import')
export class PriceImportController {
  constructor(private service: PriceImportService) {}

  @Post('preview')
  @ApiOperation({ summary: 'Revisar precios con IVA sin crear productos ni modificar precios.' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', required: ['file', 'listaId'], properties: {
    file: { type: 'string', format: 'binary' }, listaId: { type: 'string', format: 'uuid' },
  } } })
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_XLSX_BYTES, files: 1, fields: 1, parts: 3 } }))
  preview(@UploadedFile() file: Express.Multer.File, @Body() dto: PriceImportPreviewDto,
    @CurrentUser() user: { sub: string; roles: string[]; permissions: string[] }) {
    return this.service.preview(file, dto.listaId, { userId: user.sub, roles: user.roles, permissions: user.permissions });
  }
}
