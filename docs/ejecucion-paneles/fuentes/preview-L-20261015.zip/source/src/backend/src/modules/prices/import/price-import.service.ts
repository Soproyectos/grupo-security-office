import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { createHash } from 'crypto';
import { AclService, AccessContext } from '../../../common/acl/acl.service';
import { hasAction } from '../../../common/security/access-catalog';
import { PrismaService } from '../../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { readPriceTemplate } from './price-template';
import { PriceImportIssue, PriceImportPreview } from './price-import.types';

@Injectable()
export class PriceImportService {
  constructor(private prisma: PrismaService, private acl: AclService, private audit: AuditService) {}

  async preview(file: Express.Multer.File | undefined, listaId: string, ctx: AccessContext): Promise<PriceImportPreview> {
    if (!ctx.userId || !['prices:preview', 'prices:read', 'listas:read'].every((p) => hasAction(ctx, p))) {
      throw new ForbiddenException('No tienes asignada la revisión de archivos de precios.');
    }
    await this.acl.assertListaAccess(listaId, ctx, 'view_prices');
    const lista = await this.prisma.lista.findUnique({ where: { id: listaId }, select: {
      id: true, isActive: true, archivedAt: true, deletionStatus: true, currency: true,
    } });
    if (!lista) throw new NotFoundException('Lista no encontrada.');
    if (!lista.isActive || lista.archivedAt || lista.deletionStatus) throw new BadRequestException('La lista debe estar activa y disponible para revisar precios.');
    if (lista.currency !== 'COP') throw new BadRequestException('Esta plantilla solo admite precios en pesos colombianos.');
    if (!file?.buffer || !/\.xlsx$/i.test(file.originalname)) throw new BadRequestException('Selecciona la plantilla de Excel guardada como .xlsx.');

    const { tariffs, rows } = readPriceTemplate(file.buffer);
    const now = new Date();
    const priceLists = await this.prisma.priceList.findMany({
      where: { code: { in: tariffs } },
      select: { id: true, code: true, isActive: true, currency: true, validFrom: true, validUntil: true },
    });
    const configured = new Map(priceLists.map((p) => [p.code, p]));
    const issues: PriceImportIssue[] = [];
    const unavailable = new Set<string>();
    for (const code of tariffs) {
      const tariff = configured.get(code);
      if (!tariff || !tariff.isActive || tariff.currency !== 'COP' ||
        (tariff.validFrom && tariff.validFrom > now) || (tariff.validUntil && tariff.validUntil <= now)) {
        unavailable.add(code);
        issues.push({ row: null, column: code, code: 'TARIFF_UNAVAILABLE',
          message: `La tarifa ${code} no está configurada, activa o vigente en COP. Debe revisarla quien administra las tarifas.` });
      }
    }

    // Search only this Lista: an unknown or foreign reference never discloses another catalog.
    const skus = [...new Set(rows.filter((r) => !r.issues.some((i) => i.column === 'REFERENCIA')).map((r) => r.sku))];
    const products = skus.length ? await this.prisma.product.findMany({
      where: { listaId, sku: { in: skus, mode: 'insensitive' } },
      select: { id: true, sku: true, listaId: true },
    }) : [];
    // The Lista already permits view_prices. Its only overriding product rule is an explicit restriction.
    const restrictions = products.length && !this.acl.isListasAdmin(ctx.roles, ctx.permissions)
      ? await this.prisma.assignment.findMany({ where: {
        userId: ctx.userId, resourceType: 'PRODUCT', resourceId: { in: products.map((p) => p.id) }, isActive: false,
      }, select: { resourceId: true } }) : [];
    const restricted = new Set(restrictions.map((a) => a.resourceId));
    const visible = products.filter((p) => p.listaId === listaId && !restricted.has(p.id));
    const matched = new Map<string, typeof visible>();
    for (const product of visible) {
      const key = product.sku.normalize('NFC').toUpperCase();
      matched.set(key, [...(matched.get(key) ?? []), product]);
    }
    const storedPrices = visible.length ? await this.prisma.price.findMany({
      where: { productId: { in: visible.map((p) => p.id) }, priceListId: { in: priceLists.filter((p) => !unavailable.has(p.code)).map((p) => p.id) } },
      select: { productId: true, priceListId: true, listaId: true, value: true, currency: true },
    }) : [];
    const previous = new Map(storedPrices.map((p) => [`${p.productId}:${p.priceListId}`, p]));

    for (const row of rows) {
      const candidates = matched.get(row.sku.toUpperCase()) ?? [];
      const product = candidates.length === 1 ? candidates[0] : undefined;
      if (row.sku && !row.issues.some((i) => i.column === 'REFERENCIA') && !product) {
        row.issues.push({ row: row.row, column: 'REFERENCIA', code: 'REFERENCE_UNAVAILABLE',
          message: 'Esta referencia no está disponible en la lista elegida. Revisa su asignación; no se creará ni moverá ningún producto.' });
      }
      for (const price of row.prices) {
        if (unavailable.has(price.code)) {
          row.issues.push({ row: row.row, column: price.code, code: 'TARIFF_UNAVAILABLE', message: 'Esta tarifa necesita configurarse antes de actualizar sus precios.' });
          continue;
        }
        if (!product || row.issues.some((i) => i.column === 'REFERENCIA')) continue;
        const stored = previous.get(`${product.id}:${configured.get(price.code)!.id}`);
        if (!stored) continue;
        if ((stored.listaId && stored.listaId !== listaId) || stored.currency !== 'COP') {
          row.issues.push({ row: row.row, column: price.code, code: 'STORED_PRICE_MISMATCH', message: 'El precio guardado tiene una lista o moneda distinta. Debe revisarlo quien administra los precios.' });
          continue;
        }
        const oldValue = new Prisma.Decimal(stored.value);
        price.previous = oldValue.toFixed();
        price.difference = new Prisma.Decimal(price.rounded).minus(oldValue).toFixed();
        price.change = oldValue.equals(price.rounded) ? 'unchanged' : 'changed';
      }
      row.status = row.issues.length ? 'error' : 'valid';
    }
    const valid = rows.filter((r) => r.status === 'valid');
    const prices = valid.flatMap((r) => r.prices);
    const result: PriceImportPreview = {
      listaId, fileName: file.originalname.split(/[\\/]/).pop()!.slice(0, 200), currency: 'COP', taxIncluded: true,
      rounding: 'HALF_UP', readOnly: true,
      summary: {
        rows: rows.length, validRows: valid.length, errorRows: rows.length - valid.length,
        prices: prices.length, newPrices: prices.filter((p) => p.change === 'new').length,
        changedPrices: prices.filter((p) => p.change === 'changed').length,
        unchangedPrices: prices.filter((p) => p.change === 'unchanged').length,
        roundedPrices: prices.filter((p) => p.wasRounded).length,
      }, issues: [...issues, ...rows.flatMap((r) => r.issues)], rows,
    };
    await this.audit.log({ userId: ctx.userId, action: 'price-import-preview', entity: 'LISTA', entityId: listaId,
      newValues: { fileHash: createHash('sha256').update(file.buffer).digest('hex'), summary: result.summary, tariffs, rounding: result.rounding },
      result: result.issues.length ? 'WARNING' : 'SUCCESS' });
    return result;
  }
}
