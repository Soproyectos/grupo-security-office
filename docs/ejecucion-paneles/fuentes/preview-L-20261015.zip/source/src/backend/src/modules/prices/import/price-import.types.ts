export const PRICE_IMPORT_TARIFFS = [
  'INSTALADOR_IVA', 'TIENDA_IVA', 'ORO_IVA', 'DPP_PLATINO_IVA', 'CLIENTE_FINAL_IVA',
] as const;
export type PriceImportTariff = typeof PRICE_IMPORT_TARIFFS[number];
export const MAX_PRICE_IMPORT_ROWS = 5000;

export interface PriceImportIssue {
  row: number | null;
  column?: string;
  code: string;
  message: string;
}

export interface PriceImportComparison {
  code: string;
  raw: string;
  rounded: string;
  previous: string | null;
  difference: string | null;
  wasRounded: boolean;
  change: 'new' | 'changed' | 'unchanged';
}

export interface PriceImportRow {
  row: number;
  sku: string;
  status: 'valid' | 'error';
  issues: PriceImportIssue[];
  prices: PriceImportComparison[];
}

export interface PriceImportPreview {
  listaId: string;
  fileName: string;
  currency: 'COP';
  taxIncluded: true;
  rounding: 'HALF_UP';
  readOnly: true;
  summary: {
    rows: number;
    validRows: number;
    errorRows: number;
    prices: number;
    newPrices: number;
    changedPrices: number;
    unchangedPrices: number;
    roundedPrices: number;
  };
  issues: PriceImportIssue[];
  rows: PriceImportRow[];
}
