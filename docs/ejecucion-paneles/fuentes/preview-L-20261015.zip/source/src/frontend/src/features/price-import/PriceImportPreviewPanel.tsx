import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react'
import { Button } from '../../components/ui'
import { getApiErrorMessage } from '../../lib/apiError'
import { previewPriceImport, type PriceImportPreview } from '../../services/price-import.service'
import { createPreviewRequestGate, validatePreviewFile } from './preview.utils'
import PriceImportPreviewResults from './PriceImportPreviewResults'

/** A list change remounts the form, so neither a selected file nor its results carry over. */
export default function PriceImportPreviewPanel({ listaId }: { listaId: string }) {
  return <PreviewForm key={listaId} listaId={listaId} />
}

function PreviewForm({ listaId }: { listaId: string }) {
  const [file, setFile] = useState<File | null>(null)
  const [result, setResult] = useState<PriceImportPreview | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const gate = useRef(createPreviewRequestGate()).current

  useEffect(() => () => gate.invalidate(), [gate])

  function selectFile(event: ChangeEvent<HTMLInputElement>) {
    gate.invalidate()
    const next = event.target.files?.[0] ?? null
    const fileError = validatePreviewFile(next)
    setFile(fileError ? null : next)
    setResult(null)
    setLoading(false)
    setError(fileError)
  }

  async function review(event: FormEvent) {
    event.preventDefault()
    if (!file || !listaId) return
    const request = gate.begin()
    setResult(null)
    setError('')
    setLoading(true)
    try {
      const response = await previewPriceImport(listaId, file, request.signal)
      if (gate.isCurrent(request.sequence)) setResult(response)
    } catch (cause) {
      if (gate.isCurrent(request.sequence)) setError(getApiErrorMessage(cause, 'No pudimos revisar el archivo. Inténtalo de nuevo.'))
    } finally {
      if (gate.isCurrent(request.sequence)) setLoading(false)
    }
  }

  return (
    <section className="min-w-0 space-y-5" aria-label="Revisión de precios">
      <div className="rounded-xl border border-neutral-200 bg-white p-4 sm:p-6">
        <h2 className="text-lg font-semibold text-security-800">Revisar plantilla de precios</h2>
        <p className="mt-2 text-sm text-neutral-600">Sube el Excel con la hoja PRECIOS. Revisaremos las referencias y compararemos los precios con los de esta lista.</p>
        <p className="mt-2 rounded-lg bg-blue-50 p-3 text-sm text-blue-900">Esta revisión no cambia ningún precio ni publica productos. Los precios incluyen IVA y se redondean a pesos enteros.</p>
        <form onSubmit={review} className="mt-5 space-y-3" aria-busy={loading}>
          <label htmlFor="price-preview-file" className="block text-sm font-medium text-neutral-700">Plantilla de precios (.xlsx)</label>
          <input id="price-preview-file" type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={selectFile} className="block w-full min-w-0 text-sm file:mr-3 file:rounded-lg file:border file:border-neutral-200 file:bg-neutral-50 file:px-3 file:py-2" />
          <p className="text-xs text-neutral-500">Máximo 5 MB y 5000 filas de productos por archivo.</p>
          <p className="text-xs text-neutral-500">Las celdas vacías conservan el precio actual. Las referencias deben existir y pertenecer a esta lista.</p>
          <Button type="submit" loading={loading} disabled={!file || !listaId}>{loading ? 'Revisando…' : 'Revisar archivo'}</Button>
          {loading && <p role="status" className="text-sm text-neutral-600">Estamos comprobando el archivo. Puedes elegir otro para cancelar esta revisión.</p>}
        </form>
        {error && <p role="alert" className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      </div>
      {result && <PriceImportPreviewResults result={result} />}
    </section>
  )
}
