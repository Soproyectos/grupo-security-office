import { beforeEach, describe, expect, it, vi } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import ListaDetailPage from '../../pages/ListaDetailPage'

const mocks = vi.hoisted(() => ({ permissions: new Set<string>(), query: vi.fn() }))
vi.mock('../../lib/rbac', () => ({ hasPermission: (p: string) => mocks.permissions.has(p), canManageListas: () => false, canDeletePrices: () => false }))
vi.mock('react-router-dom', () => ({ useParams: () => ({ id: 'fixture-list' }), useNavigate: () => vi.fn(), Link: () => null }))
vi.mock('@tanstack/react-query', () => ({
  useQuery: (options: { queryKey: string[]; enabled: boolean }) => {
    mocks.query(options)
    return { data: options.queryKey[0] === 'lista' ? { id: 'fixture-list', name: 'Lista prueba', code: 'PRUEBA', currency: 'COP', isActive: true, updatedAt: '2026-10-14T12:00:00Z' } : undefined, isLoading: false, error: null }
  },
  useQueryClient: () => ({}), useMutation: () => ({}),
}))

describe('price review list access', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mocks.permissions = new Set(['listas:read', 'prices:read', 'prices:preview'])
  })

  it('opens review without requiring or fetching Biblioteca or the legacy importer', () => {
    const html = renderToStaticMarkup(<ListaDetailPage />)
    expect(html).toContain('Revisar precios')
    expect(html).toContain('Revisar plantilla de precios')
    expect(html).not.toContain('Importar desde Excel')
    expect(html).not.toContain('Descargar plantilla')
    const queries = mocks.query.mock.calls.map(([q]) => q as { queryKey: string[]; enabled: boolean })
    expect(queries.find(q => q.queryKey[0] === 'lista-products')?.enabled).toBe(false)
    expect(queries.find(q => q.queryKey[0] === 'lista-prices')?.enabled).toBe(false)
  })

  it.each(['prices:preview', 'prices:read', 'listas:read'])('hides review without %s', permission => {
    mocks.permissions.delete(permission)
    const html = renderToStaticMarkup(<ListaDetailPage />)
    expect(html).not.toContain('Revisar precios')
    expect(html).not.toContain('Revisar plantilla de precios')
  })
})
