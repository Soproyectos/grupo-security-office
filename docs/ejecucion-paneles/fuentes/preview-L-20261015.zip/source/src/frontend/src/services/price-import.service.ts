import api from './api'

export interface PriceImportIssue {
  row: number | null
  column?: string
  code: string
  message: string
}

export interface PreviewPrice {
  code: string
  raw: string
  rounded: string
  previous: string | null
  difference: string | null
  wasRounded: boolean
  change: 'new' | 'changed' | 'unchanged'
}

export interface PriceImportRow {
  row: number
  sku: string
  status: 'valid' | 'error'
  issues: PriceImportIssue[]
  prices: PreviewPrice[]
}

export interface PriceImportPreview {
  listaId: string
  fileName: string
  currency: 'COP'
  taxIncluded: true
  rounding: 'HALF_UP'
  readOnly: true
  summary: {
    rows: number
    validRows: number
    errorRows: number
    prices: number
    newPrices: number
    changedPrices: number
    unchangedPrices: number
    roundedPrices: number
  }
  issues: PriceImportIssue[]
  rows: PriceImportRow[]
}

export async function previewPriceImport(listaId: string, file: File, signal?: AbortSignal): Promise<PriceImportPreview> {
  const form = new FormData()
  form.append('listaId', listaId)
  form.append('file', file)
  const response = await api.post<PriceImportPreview>('/prices/import/preview', form, { signal })
  return response.data
}
